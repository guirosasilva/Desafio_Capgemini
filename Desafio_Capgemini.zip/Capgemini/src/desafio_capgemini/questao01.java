package desafio_capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class questao01 {
	public static void main(String args[]) throws IOException {
		//Leitura da entrada de dados (quantidade de degraus desejada)
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Quantos degrais terá a escada? \n");
		//Leitura feita em formato texto, convertida para valor inteiro
		String se = br.readLine();
		int qtdDegrau = Integer.parseInt(se);
		String espaco = " ";
		String degrau = "*";
		String saida = "";

		// cria contador para delimitar a quantdade de espaços antes da criação do degrau com desenho de *
		int cont = qtdDegrau - 1;
		// criar linhas (quantidade de degraus) do tamanho requerido
		for (int i = 0; i < qtdDegrau; i++) {
			saida = saida + espaco;
		}
		// cria as proximas linhas com os degruas nescessarios
		for (int j = 0; j < qtdDegrau; j++) {
			saida = saida.substring(0, cont) + degrau + saida.substring(cont + 1);
			//variável saída armazena o desenho de cada linha onde constam espaços e asterisco que formam o desenho da escada
			//Reduz variável cont para saber quantos caracteres de espaço serão desenhados por linha, no último degrau o cont = 0, linha toda preenchida por asterisco.
			cont--;
			//Desenha (imprime) na tela o conteúdo da varivável saída baseado na quantidade de degraus solicitada 
			System.out.println(saida);

		}
		if (qtdDegrau == 1) {
			System.out.println("\nA escada foi criada com apenas " + qtdDegrau + " degrau.\n");
		} else {
			System.out.println("\nA escada foi criada com " + qtdDegrau + " degraus.\n");
		}
	}
}
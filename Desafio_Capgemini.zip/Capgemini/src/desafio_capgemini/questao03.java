package desafio_capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class questao03 {
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Teste de anagrama!\nPor favor digite o anagrama para teste:");

		String palavra = br.readLine();

		int cont = 0;
		int cont2 = 0;
		int cont3 = 0;
		
		//Variável que armazenará subparte do conteúdo 
		String testeAnagrama = "";
		
		//Matriz (array) que conterá conteúdo das variações (subpartes) das palavras
		String[] subpalavras = new String[palavra.length() * palavra.length()];

		for (int i = 0; i <= palavra.length() - 1; i++) {
			for (int j = 0; j <= palavra.length(); j++) {

				//Compara quantidade de caracter com conteúdo original, pois não pode ir além
				if (cont > palavra.length()) {
					cont = 0;
				}
				//Compara e percorre caracter
				if (i == cont || (palavra.length() - j >= palavra.length() - i)) {
					cont++;
				} else {
					//Armazena as subpartes
					testeAnagrama = palavra.substring(i, cont);
					cont++;
					
					subpalavras[cont2] = testeAnagrama;
					cont2++;
				}
			}
		}
		for (int i = 0; i < subpalavras.length; i++) {
			for (int j = 0; j < subpalavras.length; j++) {

				//Comapara se é vazio conteúdo
				if (subpalavras[j] == null) {
					subpalavras[j] = "";
				}

				//Testa subpartes e contabiliza quantas são
				if (IsAnagrama(subpalavras[i], subpalavras[j]) && i != j && subpalavras[i] != "") {

  				  cont3++;
				} else {
					//Não é anagrama (pares)
				}
			}

		}
		
		//Divide em pares o contador (conteúdo)
		cont3 = cont3 / 2;
		System.out.println("A palavra "+palavra+ " possui "+ cont3 + " anagramas pares");
		System.out.println(cont3);
	}

	public static boolean IsAnagrama(String part1, String part2) {

		// Transforma em arrays para poder ordenar e comparar depois (cada caracter)
		char[] p1 = part1.toCharArray();
		char[] p2 = part2.toCharArray();
		// Ordena para garantir a comparação simplificada
		Arrays.sort(p1);
		Arrays.sort(p2);
		// Cria as novas strings baseadas nos arrays ordenados (facilitando a comparação)
		String sp1 = new String(p1);
		String sp2 = new String(p2);

		//Retorna verdadeiro caso comparação resulte em igualdade
		return sp1.equals(sp2);
	}
}
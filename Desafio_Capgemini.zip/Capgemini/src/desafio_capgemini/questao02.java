package desafio_capgemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class questao02 {

	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Validação de senha forte! ?\nPor favor digite a senha para validação:");

		String senha = br.readLine();
		
		//Efetua leitura da senha mediante conteúdo armazenado no buffer

		
		//Executa validação mediante função (verdadeiro se forte, falso se fraca)
		Boolean verificada = senhaForte(senha);

		if (verificada) {
			System.out.println("Conteúdo da inserida é forte!");
		} else {
			//Compara (diminu) quantidade de caracteres informados pela quantidade mínima exigida de 06(seis) caracteres, se for menor, informa que senha é curta!
			if (senha != null) {
			  if (senha.length() < 6) {
				int faltante = 6 - senha.length();
				System.out.println("Senha curta faltam " + faltante + " caracteres!");
			  }
			}
			System.out.println("Senha não é forte");
		}

	}
	public static Boolean senhaForte(String senha) {
		//Aviso textual sobre possíveis falhas (erros) no conteúdo da senha informada
		String maiu = " Falta uma letra maiúscula! ";
		String minus = " Falta uma letra minúscula! ";
		String numero = " Falta um número! ";
		String esp = " Falta um caracter especial! ";
		String erro = "Erro encontrado -";
		//verifica tamanho da senha digitada
		if (senha != null) {
		  if (senha.length() < 6)
			return false; //retorna falso caso conteúdo (comprimento) seja menor que 06 (seis) caracteres
		 }

		boolean achouNumero = false;
		boolean achouMaiuscula = false;
		boolean achouMinuscula = false;
		boolean achouSimbolo = false;
		
		//Verifica a senha em cada um dos requisitos de segurança para ser considerada forte
		//Transforma (separa/quebra) conteúdo da palavra (senha) em vários pedaços (caracteres) para posterior validação
		if (senha != null) {
		for (char c : senha.toCharArray()) {
			//compara se há número
			if (c >= '0' && c <= '9') {
				achouNumero = true;
			//compara se é letra maiúscula
			} else if (c >= 'A' && c <= 'Z') {
				achouMaiuscula = true;
			//compara se é letra minúscula
			} else if (c >= 'a' && c <= 'z') {
				achouMinuscula = true;
			} else {
			//compara se é símbolo (caractere especial)
				achouSimbolo = true;
			}
		   }
		}
		// verifica se foi encontrado algum erro e quais os erros encontrados para cada opcao de erro 
		//se não encontrou nenhum número
		if (!achouNumero) {
			erro = erro + numero;
		}
		//se não encontrou nenhuma letra maiúscula
		if (!achouMaiuscula) {
			erro = erro + maiu;
		}
		//se não encontrou nenhuma letra minúscula
		if (!achouMinuscula) {
			erro = erro + minus;
		}
		//se não encontrou nenhum símbolo (caractere especial)
		if (!achouSimbolo) {
			erro = erro + esp;
		}
		// verifica se tem algum erro para apresentar no terminal
		if (!achouNumero || !achouMaiuscula || !achouMinuscula || !achouSimbolo) {
			System.out.println(erro);
		}
		return achouNumero && achouMaiuscula && achouMinuscula && achouSimbolo;
	}
}